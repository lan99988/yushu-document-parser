# Copyright (c) Opendatalab. All rights reserved.
from __future__ import annotations

import os
import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Literal

import requests
from filelock import FileLock
from huggingface_hub import HfApi
from huggingface_hub import snapshot_download as hf_snapshot_download
from huggingface_hub.utils import filter_repo_objects
from loguru import logger

from ..config import config, get_config_source, update_config_file

if TYPE_CHECKING:
    from ..config import ModelSource

DownloadMode = Literal["full", "required_paths"]
MODEL_COMPLETE_MARKER = ".mineru_complete"


def _join_model_path(*parts: str) -> str:
    """连接并校验模型仓库内的相对路径片段。"""
    cleaned: list[str] = []
    for raw in parts:
        value = str(raw).replace("\\", "/").strip("/")
        if not value:
            continue
        cleaned.extend(part for part in value.split("/") if part and part != ".")
    if any(part == ".." for part in cleaned):
        raise ValueError("Model paths must not contain '..' segments.")
    return "/".join(cleaned)


@dataclass(frozen=True)
class ModelPath:
    """表示模型仓库中的一个具名相对路径。"""

    repo: "ModelRepo"
    name: str
    relative_path: str

    def path(self, relative_path: str, /, *children: str) -> "ModelPath":
        """基于当前路径派生一个更深的模型路径。"""
        joined = _join_model_path(self.relative_path, relative_path, *children)
        name = _join_model_path(self.name, relative_path, *children)
        return ModelPath(repo=self.repo, name=name, relative_path=joined)

    def local_path(self) -> Path:
        """返回该模型路径在本地模型根目录中的位置。"""
        return self.repo.local_dir() / self.relative_path

    def ensure(self, *, source: "ModelSource | None" = None) -> Path:
        """确保当前模型路径已下载并返回本地位置。"""
        download_model_files(self.repo, [self], source=source, reuse_ready=True)
        return self.local_path()


@dataclass(frozen=True)
class ModelRepo:
    """定义一个可从多来源获取的模型仓库。"""

    name: str
    repos: dict[str, str]
    local_name: str = ""
    paths: dict[str, str] = field(default_factory=dict)
    download_mode: DownloadMode = "full"

    def __post_init__(self) -> None:
        """缺少本地名称时使用稳定仓库名。"""
        if not self.local_name:
            object.__setattr__(self, "local_name", self.name)

    def __getattr__(self, name: str) -> ModelPath:
        """允许通过具名字段读取仓库预定义路径。"""
        try:
            return self.named_path(name)
        except KeyError as exc:
            raise AttributeError(name) from exc

    def named_path(self, name: str) -> ModelPath:
        """返回仓库中已声明的具名模型路径。"""
        return ModelPath(repo=self, name=name, relative_path=self.paths[name])

    def path(self, relative_path: str, /, *children: str) -> ModelPath:
        """按任意安全相对路径构造模型路径。"""
        joined = _join_model_path(relative_path, *children)
        return ModelPath(repo=self, name=joined, relative_path=joined)

    def required_paths(self) -> tuple[ModelPath, ...]:
        """返回仓库声明的全部必需路径。"""
        return tuple(self.named_path(name) for name in self.paths)

    def local_dir(self) -> Path:
        """返回仓库在 MinerU 模型目录中的本地根路径。"""
        return Path(config.model.base_dir).expanduser() / self.local_name

    def lock_path(self) -> Path:
        """返回仓库下载互斥锁的稳定路径。"""
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", self.local_name).strip("._") or "model"
        return Path(config.model.base_dir).expanduser() / ".locks" / f"{safe_name}.lock"

    def ensure(self, *, source: "ModelSource | None" = None) -> Path:
        """确保完整仓库可用并返回本地根路径。"""
        return download_model_repo(self, source=source, reuse_ready=True)


MODEL_SOURCE_ENV_VAR = "MINERU_MODEL_SOURCE"
_HUGGINGFACE_MODELS_PAGE_URL = "https://huggingface.co/models"
_HUGGINGFACE_MODELS_PAGE_TIMEOUT = 3
_HUGGINGFACE_MODELS_PAGE_MAX_ATTEMPTS = 2
_REMOTE_MODEL_SOURCES = ("huggingface", "modelscope")
DOWNLOAD_MODEL_SOURCES = ("auto", *_REMOTE_MODEL_SOURCES)
ResolvedRemoteModelSource = Literal["huggingface", "modelscope"]
ResolvedModelSource = Literal["huggingface", "modelscope", "local"]
_PROVIDER_METADATA_DIR_NAMES = {".cache", "._____temp"}
_PROVIDER_METADATA_FILE_NAMES = {MODEL_COMPLETE_MARKER, ".msc", ".mdl", ".mv"}


def ms_snapshot_download(repo_id: str, *, local_dir: str, allow_patterns: list[str] | None = None) -> str:
    """仅在实际使用 ModelScope 时导入 SDK，避免 HF/本地路径触发其 Torch 探测。"""
    from modelscope import snapshot_download

    return snapshot_download(repo_id, local_dir=local_dir, allow_patterns=allow_patterns)


@dataclass(frozen=True)
class ModelReadyResult:
    ready: bool
    root: Path
    missing_paths: list[str] = field(default_factory=list)


def _normalize_source(raw_source: object, *, strict: bool) -> str:
    source = str(raw_source or "auto").strip().lower()
    if source in {"auto", "huggingface", "modelscope", "local"}:
        return source
    if strict:
        expected = ", ".join(DOWNLOAD_MODEL_SOURCES)
        raise ValueError(f"Unsupported model source '{raw_source}'. Expected one of: {expected}.")
    logger.warning(f"Unsupported model source {raw_source!r}; falling back to auto.")
    return "auto"


def _resolve_auto_model_source() -> ResolvedRemoteModelSource:
    """Resolve auto source by probing Hugging Face reachability."""
    last_error = None
    for _ in range(_HUGGINGFACE_MODELS_PAGE_MAX_ATTEMPTS):
        try:
            response = requests.get(
                _HUGGINGFACE_MODELS_PAGE_URL,
                timeout=_HUGGINGFACE_MODELS_PAGE_TIMEOUT,
            )
            if 200 <= response.status_code < 400:
                return "huggingface"
            last_error = f"status_code={response.status_code}"
        except Exception as exc:
            last_error = str(exc)

    logger.warning("Failed to access %s: %s, fallback to modelscope.", _HUGGINGFACE_MODELS_PAGE_URL, last_error)
    return "modelscope"


def _persist_resolved_model_source(model_source: str) -> None:
    if model_source not in _REMOTE_MODEL_SOURCES:
        return
    try:
        update_config_file({"model": {"source": model_source}})
    except Exception as exc:
        logger.warning(f"Failed to persist resolved model source {model_source!r}: {exc}")


def resolve_model_source(
    model_source: str | None = None,
    *,
    allow_auto: bool = False,
    local_as_auto: bool = False,
) -> ResolvedModelSource:
    """Resolve the effective model source.

    Explicit ``model_source`` is CLI input and is validated strictly. When no
    explicit source is supplied, ``config.model.source`` may come from config
    file, environment, or defaults; invalid values are treated as auto.
    """
    explicit_source = model_source is not None
    raw_source = model_source if explicit_source else config.model.source
    normalized_source = _normalize_source(raw_source, strict=explicit_source)

    if explicit_source and normalized_source == "local":
        raise ValueError("--source does not support 'local'. Use auto, huggingface, or modelscope.")

    if normalized_source == "local":
        if not local_as_auto:
            return "local"
        normalized_source = "auto"

    if normalized_source in _REMOTE_MODEL_SOURCES:
        return normalized_source  # type: ignore[return-value]

    if normalized_source != "auto":
        raise ValueError(f"Unsupported model source: {raw_source}")
    if not allow_auto:
        raise ValueError("model source auto is only supported when auto resolution is explicitly allowed.")

    resolved_model_source = _resolve_auto_model_source()
    if not explicit_source and raw_source == "auto" and get_config_source("model.source") in {"default", "file"}:
        _persist_resolved_model_source(resolved_model_source)
    return resolved_model_source


def _source_repo_id(repo: ModelRepo, model_source: str) -> str:
    """校验仓库是否已发布到所选来源，避免错误回退到旧仓库。"""
    if model_source not in repo.repos:
        available = ", ".join(repo.repos)
        raise ValueError(f"Model repo {repo.name} is not available from {model_source}. Available sources: {available}.")
    return repo.repos[model_source]


def _snapshot_download(model_source: ResolvedRemoteModelSource, repo: ModelRepo, patterns: list[str] | None) -> str:
    """下载已配置来源的快照，并验证远程清单中的文件均已落盘。"""
    repo_id = _source_repo_id(repo, model_source)
    local_dir = repo.local_dir()
    local_dir.parent.mkdir(parents=True, exist_ok=True)
    kwargs = {"local_dir": str(local_dir)}
    if patterns is not None:
        kwargs["allow_patterns"] = patterns
    if model_source == "huggingface":
        # Hugging Face may return a non-empty local_dir when the remote repo is unavailable, so verify the expected
        # remote manifest before treating the snapshot as complete.
        expected_files = list(filter_repo_objects(HfApi().list_repo_files(repo_id), allow_patterns=patterns))
        if not expected_files:
            raise FileNotFoundError(f"Hugging Face snapshot for {repo.name} has no files matching the requested paths.")
        root = hf_snapshot_download(repo_id, **kwargs)
        missing_files = [path for path in expected_files if not (local_dir / path).is_file()]
        if missing_files:
            missing = ", ".join(missing_files)
            raise FileNotFoundError(f"Hugging Face snapshot for {repo.name} is incomplete; missing: {missing}")
        return root
    return ms_snapshot_download(repo_id, **kwargs)


def _path_patterns(paths: list[str]) -> list[str]:
    patterns: list[str] = []
    for path in paths:
        normalized = path.strip("/")
        if not normalized:
            continue
        patterns.extend([normalized, f"{normalized}/*"])
    return patterns


def _relative_paths(repo: ModelRepo, paths: Sequence[str | ModelPath]) -> list[str]:
    relative_paths: list[str] = []
    for path in paths:
        if isinstance(path, ModelPath):
            if path.repo is not repo:
                raise ValueError(f"Model path {path.relative_path!r} belongs to repo {path.repo.name!r}, not {repo.name!r}.")
            relative_paths.append(path.relative_path)
        else:
            relative_paths.append(str(path).strip("/"))
    return relative_paths


def _verify_paths(repo: ModelRepo, paths: Sequence[str | ModelPath]) -> ModelReadyResult:
    model_paths = [path if isinstance(path, ModelPath) else repo.path(path) for path in paths]
    missing = [path.relative_path for path in model_paths if not model_path_exists(path)]
    return ModelReadyResult(ready=not missing, root=repo.local_dir(), missing_paths=missing)


def _directory_has_payload(path: Path) -> bool:
    for _root, dir_names, file_names in os.walk(path):
        dir_names[:] = [name for name in dir_names if name not in _PROVIDER_METADATA_DIR_NAMES]
        if any(name not in _PROVIDER_METADATA_FILE_NAMES for name in file_names):
            return True
    return False


def _payload_path_exists(path: ModelPath) -> bool:
    local_path = path.local_path()
    if local_path.is_file():
        return True
    if not local_path.is_dir():
        return False
    return _directory_has_payload(local_path)


def _verify_downloaded_paths(repo: ModelRepo, paths: Sequence[str | ModelPath]) -> ModelReadyResult:
    model_paths = [path if isinstance(path, ModelPath) else repo.path(path) for path in paths]
    missing = [path.relative_path for path in model_paths if not _payload_path_exists(path)]
    return ModelReadyResult(ready=not missing, root=repo.local_dir(), missing_paths=missing)


def _repo_completion_paths(repo: ModelRepo) -> list[ModelPath]:
    if repo.download_mode == "full":
        return [repo.path("")]
    return list(repo.required_paths())


def _remove_directory_markers(paths: Sequence[ModelPath]) -> list[Path]:
    removed_markers: list[Path] = []
    for path in paths:
        local_path = path.local_path()
        if not local_path.is_dir():
            continue
        repo_root = path.repo.local_dir()
        for directory in (local_path, *local_path.parents):
            marker = directory / MODEL_COMPLETE_MARKER
            if marker.is_file():
                marker.unlink()
                removed_markers.append(marker)
            if directory == repo_root:
                break
    return removed_markers


def _mark_directories_complete(paths: Sequence[ModelPath]) -> None:
    for path in paths:
        local_path = path.local_path()
        if local_path.is_dir():
            (local_path / MODEL_COMPLETE_MARKER).touch(exist_ok=True)


def _restore_directory_markers(markers: Sequence[Path]) -> None:
    for marker in markers:
        marker.touch(exist_ok=True)


def _raise_not_ready(repo: ModelRepo, result: ModelReadyResult) -> None:
    missing = ", ".join(result.missing_paths)
    raise FileNotFoundError(f"Model repo {repo.name} is not ready under {result.root}; missing: {missing}")


def download_model_repo(
    repo: ModelRepo,
    *,
    source: str | None = None,
    local_as_auto: bool = False,
    reuse_ready: bool = False,
) -> Path:
    completion_paths = _repo_completion_paths(repo)
    relative_paths = [path.relative_path for path in completion_paths] if repo.download_mode == "required_paths" else None
    lock_path = repo.lock_path()
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with FileLock(str(lock_path)):
        if reuse_ready:
            ready_result = verify_model_repo(repo)
            if ready_result.ready:
                return ready_result.root

        resolved_source = resolve_model_source(source, allow_auto=True, local_as_auto=local_as_auto)
        if resolved_source == "local":
            result = verify_model_repo(repo)
            if not result.ready:
                _raise_not_ready(repo, result)
            return result.root

        _source_repo_id(repo, resolved_source)
        removed_markers = _remove_directory_markers(completion_paths)
        _snapshot_download(resolved_source, repo, None if relative_paths is None else _path_patterns(relative_paths))
        downloaded_result = _verify_downloaded_paths(repo, completion_paths)
        if not downloaded_result.ready:
            _raise_not_ready(repo, downloaded_result)
        _mark_directories_complete(completion_paths)
        _restore_directory_markers(removed_markers)
        return downloaded_result.root


def download_model_files(
    repo: ModelRepo,
    paths: Sequence[str | ModelPath],
    *,
    source: str | None = None,
    local_as_auto: bool = False,
    reuse_ready: bool = False,
) -> Path:
    if not paths:
        return repo.local_dir()

    model_paths = [path if isinstance(path, ModelPath) else repo.path(path) for path in paths]
    relative_paths = _relative_paths(repo, paths)
    lock_path = repo.lock_path()
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with FileLock(str(lock_path)):
        if reuse_ready:
            ready_result = _verify_paths(repo, model_paths)
            if ready_result.ready:
                return ready_result.root

        resolved_source = resolve_model_source(source, allow_auto=True, local_as_auto=local_as_auto)
        if resolved_source == "local":
            result = _verify_paths(repo, model_paths)
            if not result.ready:
                _raise_not_ready(repo, result)
            return result.root

        _source_repo_id(repo, resolved_source)
        removed_markers = _remove_directory_markers(model_paths)
        _snapshot_download(resolved_source, repo, _path_patterns(relative_paths))
        downloaded_result = _verify_downloaded_paths(repo, model_paths)
        if not downloaded_result.ready:
            _raise_not_ready(repo, downloaded_result)
        _mark_directories_complete(model_paths)
        _restore_directory_markers(removed_markers)
        return downloaded_result.root


def verify_model_repo(repo: ModelRepo) -> ModelReadyResult:
    if repo.download_mode == "full":
        marker = repo.local_dir() / MODEL_COMPLETE_MARKER
        ready = marker.is_file()
        return ModelReadyResult(
            ready=ready,
            root=repo.local_dir(),
            missing_paths=[] if ready else [MODEL_COMPLETE_MARKER],
        )
    return _verify_paths(repo, list(repo.required_paths()))


def model_path_exists(path: ModelPath) -> bool:
    """判断模型路径存在且所属目录已写入完整标记。"""
    local_path = path.local_path()
    if local_path.is_file():
        return True
    if not local_path.is_dir():
        return False
    repo_root = path.repo.local_dir()
    try:
        local_path.relative_to(repo_root)
    except ValueError:
        return False
    for directory in (local_path, *local_path.parents):
        if (directory / MODEL_COMPLETE_MARKER).is_file():
            return True
        if directory == repo_root:
            break
    return False


__all__ = [
    "DOWNLOAD_MODEL_SOURCES",
    "DownloadMode",
    "MODEL_COMPLETE_MARKER",
    "MODEL_SOURCE_ENV_VAR",
    "ModelPath",
    "ModelReadyResult",
    "ModelRepo",
    "download_model_files",
    "download_model_repo",
    "model_path_exists",
    "resolve_model_source",
    "verify_model_repo",
]
